export const ROLES = {
  Student: "Student",
  Instructor: "Instructor",
};
