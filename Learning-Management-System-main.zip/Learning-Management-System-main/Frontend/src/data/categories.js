export const categories = [
  {
    Development: [
      "Android Development",
      "iOS Development",
      "Web Development",
      "Game Development",
      "Software Testing",
      "Programming Languauge",
      "No-code Development",
    ],
  },
  {
    Finance: [
      "Accounting",
      "Economics",
      "Finance",
      "Taxes",
      "Investing",
      "Money Management Tools",
      "Compliance",
    ],
  },
  {
    Design: [
      "Web Design",
      "Desing Tools",
      "Game Design",
      "Fashion Design",
      "Architectural Design",
      "Other Design",
    ],
  },
  {
    "Personal Development": [
      "Personal Transformation",
      "Leadership",
      "Career Development",
      "Happiness",
      "Creativity",
      "Influence",
    ],
  },
  {
    Lifestyle: [
      "Arts",
      "Makeup",
      "Food",
      "Gaming",
      "Travel",
      "Home Improvement",
    ],
  },
  {
    Business: [
      "Entrepreneueship",
      "Communication",
      "Management",
      "Sales",
      "Operations",
      "Business Law",
      "Industry",
      "Media",
    ],
  },
];
